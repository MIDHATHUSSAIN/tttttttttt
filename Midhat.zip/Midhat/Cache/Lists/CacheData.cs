﻿using Cache.FilesPath;
using Repo.Repos;
using System.Collections.ObjectModel;
using Uitilies.SerilizationAndDeserilization;

namespace Cache.Lists
{
    public class CacheData
    {
        public static ObservableCollection<Student> Students { get; set; } = new();
        public static ObservableCollection<User> Users { get; set; } = new();
        public static ObservableCollection<Teacher> Teachers { get; set; } = new();
        public static ObservableCollection<Announcement> Announcemts { get; set; } = new();
        public static ObservableCollection<Courses> Courses { get; set; } = new();
        public static ObservableCollection<Attendance> Attendances { get; set; } = new();
        public static ObservableCollection<Result> Results { get; set; } = new();
        public static ObservableCollection<Admission> Admissions { get; set; } = new();
        public static void LoadingInitialData()
        {
            Students = SerilizingAndDeserilizing.LoadData<Student>(Constants.StudentFilePath, "Students");
            Teachers = SerilizingAndDeserilizing.LoadData<Teacher>(Constants.TeacherFilePath, "Teachers");
            Users = SerilizingAndDeserilizing.LoadData<User>(Constants.UserFilePath, "Users");
            Announcemts = SerilizingAndDeserilizing.LoadData<Announcement>(Constants.AnnouncementFilePath, "Announcements");
            Courses = SerilizingAndDeserilizing.LoadData<Courses>(Constants.CoursesFilePath, "Course");
            Attendances = SerilizingAndDeserilizing.LoadData<Attendance>(Constants.AttendanceFilePath, "Attendances");
            Results = SerilizingAndDeserilizing.LoadData<Result>(Constants.ResultFilePath, "Results");
            Admissions = SerilizingAndDeserilizing.LoadData<Admission>(Constants.AdmissionFilePath, "Admissions");
        }

        public static void BeforeClosingLogic()
        {
            SerilizingAndDeserilizing.SaveData(Constants.StudentFilePath,Students,"Students");
            SerilizingAndDeserilizing.SaveData(Constants.UserFilePath,Users, "Users");
            SerilizingAndDeserilizing.SaveData(Constants.TeacherFilePath,Teachers, "Teachers");
            SerilizingAndDeserilizing.SaveData(Constants.CoursesFilePath,Courses, "Course");
            SerilizingAndDeserilizing.SaveData(Constants.AnnouncementFilePath,Announcemts, "Announcements");
            SerilizingAndDeserilizing.SaveData(Constants.AttendanceFilePath,Attendances, "Attendances");
            SerilizingAndDeserilizing.SaveData(Constants.ResultFilePath,Results, "Results");
            SerilizingAndDeserilizing.SaveData(Constants.AdmissionFilePath,Admissions, "Admissions");

            Console.WriteLine("All data saved successfully.");
        }
    }


}
