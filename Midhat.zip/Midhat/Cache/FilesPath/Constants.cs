﻿namespace Cache.FilesPath
{
    public class Constants
    {
        public static string StudentFilePath = @"D:\Downloads\Midhat\Midhat\Midhat\Uitilies\Files\StudentsData.xml";
        public static string TeacherFilePath = @"D:\Downloads\Midhat\Midhat\Midhat\Uitilies\Files\TeachersData.xml";
        public static string UserFilePath = @"D:\Downloads\Midhat\Midhat\Midhat\Uitilies\Files\UsersData.xml";
        public static string AnnouncementFilePath = @"D:\Downloads\Midhat\Midhat\Midhat\Uitilies\Files\AnnouncementData.xml";
        public static string CoursesFilePath = @"D:\Downloads\Midhat\Midhat\Midhat\Uitilies\Files\CoursesData.xml";
        public static string AttendanceFilePath = @"D:\Downloads\Midhat\Midhat\Midhat\Uitilies\Files\AttendanceData.xml";
        public static string ResultFilePath = @"D:\Downloads\Midhat\Midhat\Midhat\Uitilies\Files\ResultData.xml";
        public static string AdmissionFilePath = @"D:\Downloads\Midhat\Midhat\Midhat\Uitilies\Files\AdmissionFile.xml";
    }
}
