﻿using Cache.Lists;
using ComManager.CommunicationManager.CheckingRequests;
using System.Net;
using System.Net.Sockets;
using System.Text;

namespace ComManager.CommunicationManager.ApplicatiosConnection
{
    public class MakingConnections
    {
        //// Add this at the top of your class
        private static readonly List<TcpClient> _connectedClients = new List<TcpClient>();
        private static readonly object _lock = new object();
        CheckingRequestType Cr = new CheckingRequestType();

        public void Connection()
        {
            int port = 5001;
            TcpListener server = new TcpListener(IPAddress.Any, port);
            server.Start();
            Console.WriteLine($"Server is running on {port}");

            while (true)
            {
                TcpClient client = server.AcceptTcpClient();
                Console.WriteLine("Client connected.");
                // Add to our broadcast list
                lock (_lock) { _connectedClients.Add(client); }

                //HandleClient(client);
                // IMPORTANT: Run HandleClient in a new Thread or Task 
                // so the server can keep accepting other clients!
                Task.Run(() => HandleClient(client));
            }
        }


        public void HandleClient(TcpClient client)
        {
            try
            {
                using (NetworkStream stream = client.GetStream())
                {
                    byte[] buffer = new byte[1024];
                    while (true)
                    {
                        int bytesRead = stream.Read(buffer, 0, buffer.Length);
                        if (bytesRead == 0) break; // Client disconnected gracefully

                        string requestData = Encoding.UTF8.GetString(buffer, 0, bytesRead);
                        string response = Cr.ProcessRequest(requestData);

                        // 1. Send specific response to the client who asked
                        byte[] responseBuffer = Encoding.UTF8.GetBytes(response);
                        stream.Write(responseBuffer, 0, responseBuffer.Length);

                        // 2. TRIGGER THE BROADCAST
                        // If the request was an Add/Update/Delete, tell everyone!
                        if (requestData.Contains("SAVE"))
                        {
                            Broadcast("REFRESH_DATA");

                        }

                            
                        
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Connection error: {ex.Message}");
            }
            finally
            {
                // IMPORTANT: Remove the client from the list when they leave
                lock (_lock) { _connectedClients.Remove(client); }
                client.Close();
                CacheData.BeforeClosingLogic();
                Console.WriteLine("Client removed and resources cleaned up.");
            }
        }

        public void Broadcast(string message)
        {
            byte[] buffer = Encoding.UTF8.GetBytes(message);

            lock (_lock)
            {
                // We iterate backwards so if a client is dead, we can remove it safely
                for (int i = _connectedClients.Count - 1; i >= 0; i--)
                {
                    try
                    {
                        TcpClient client = _connectedClients[i];
                        if (client.Connected)
                        {
                            NetworkStream stream = client.GetStream();
                            stream.Write(buffer, 0, buffer.Length);
                        }
                        else
                        {
                            _connectedClients.RemoveAt(i);
                        }
                    }
                    catch
                    {
                        // Connection failed, remove the client
                        _connectedClients.RemoveAt(i);
                    }
                }
            }
        }



        //public void HandleClient(TcpClient client)
        //{
        //    using (NetworkStream stream = client.GetStream())
        //    {
        //        byte[] buffer = new byte[1024];

        //        try
        //        {
        //            while (true)
        //            {
        //                int bytesRead = stream.Read(buffer, 0, buffer.Length);

        //                // If bytesRead is 0, the client has initiated a disconnect
        //                if (bytesRead == 0)
        //                {
        //                    CacheData.BeforeClosingLogic();
        //                    break;
        //                }

        //                string requestData = Encoding.UTF8.GetString(buffer, 0, bytesRead);
        //                string response = Cr.ProcessRequest(requestData);

        //                byte[] responseBuffer = Encoding.UTF8.GetBytes(response);
        //                stream.Write(responseBuffer, 0, responseBuffer.Length);
        //            }
        //        }
        //        catch (Exception ex)
        //        {
        //            Console.WriteLine($"Connection lost unexpectedly: {ex.Message}");
        //            CacheData.BeforeClosingLogic();
        //        }
        //        //finally
        //        //{
        //        //    client.Close();
        //        //    AfterClosingLogic();
        //        //}
        //    }
        //}

        //private void BeforeClosingLogic()
        //{
        //    Console.WriteLine("Running abc function BEFORE closing...");
        //    Sd.SaveData("students.xml", MyCache.Students);

        //    // Save Users
        //    Sd.SaveData("users.xml", MyCache.Users);

        //    // Save Teachers
        //    Sd.SaveData("teachers.xml", MyCache.Teachers);

        //    Console.WriteLine("All data saved successfully.");
        //}
        //private void AfterClosingLogic()
        //{
        //    Console.WriteLine("Running abc function AFTER closing...");
        //    // Your post-close logic here
        //}
    }
}
