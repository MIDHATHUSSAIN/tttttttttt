﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Repo.Repos
{
    public class Result
    {
        public decimal Marks { get; set; }
        public string Name { get; set; }
        public string SubjectName {  get; set; } 
        public string className { get; set; }
        public string email { get; set; }
        public decimal TotalMarks { get; set; }
        public DateTime Date { get; set; } = DateTime.Now;
    }
}
