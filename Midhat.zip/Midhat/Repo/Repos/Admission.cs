﻿namespace Repo.Repos
{
    public class Admission
    {
        public string StartingYear { get; set; }
        public string EndingYear { get; set; }
    }
}
