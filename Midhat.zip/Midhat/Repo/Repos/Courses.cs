﻿namespace Repo.Repos
{
    public class Courses
    {
        private string className;
        private string subjectName1;
        private string subjectName2;
        private string subjectName3;
        private string subjectName4;
        private string subjectName5;
        private string subjectName6;
        private string subjectName7;
        private string subject1BookName;
        private string subject2BookName;
        private string subject3BookName;
        private string subject4BookName;
        private string subject5BookName;
        private string subject6BookName;
        private string subject7BookName;

        public string ClassName
        {
            get { return className; }
            set { className = value; }
        }

        public string SubjectName1
        {
            get { return subjectName1; }
            set { subjectName1 = value; }
        }

        public string SubjectName2
        {
            get { return subjectName2; }
            set { subjectName2 = value; }
        }
        public string SubjectName3
        {
            get { return subjectName3; }
            set { subjectName3 = value; }

        }
        public string SubjectName4
        {
            get { return subjectName4; }
            set { subjectName4 = value; }
        }
        public string SubjectName5
        {
            get { return subjectName5; }
            set { subjectName5 = value; }
        }
        public string SubjectName6
        {
            get { return subjectName6; }
            set { subjectName6 = value; }
        }
        public string SubjectName7
        {
            get { return subjectName7; }
            set { subjectName7 = value; }
        }
        public string Subject1BookName
        {
            get { return subject1BookName; }
            set { subject1BookName = value; }
        }
        public string Subject2BookName
        {
            get { return subject2BookName; }
            set { subject2BookName = value; }
        }
        public string Subject3BookName
        {
            get { return subject3BookName; }
            set { subject3BookName = value; }
        }

        public string Subject4BookName
        {
            get { return subject4BookName; }
            set { subject4BookName = value; }
        }
        public string Subject5BookName
        {
            get { return subject5BookName; }
            set { subject5BookName = value; }
        }
        public string Subject6BookName
        {
            get { return subject6BookName; }
            set { subject6BookName = value; }
        }
        public string Subject7BookName
        {
            get { return subject7BookName; }
            set { subject7BookName = value; }
        }

        public DateTime CreatedAt { get; set; }= DateTime.Now;
    }
}
