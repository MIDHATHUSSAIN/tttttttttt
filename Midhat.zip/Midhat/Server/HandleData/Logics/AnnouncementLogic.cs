﻿using Cache.Lists;
using Repo.Repos;
using System.Collections.ObjectModel;

namespace Server.HandleData.Logics
{
     public class AnnouncementLogic
    {
        public ObservableCollection<Announcement> AddAnnouncement(Announcement AnnouncemetData)
        {
            var announcement = CacheData.Announcemts.Where(x => x.AnnouncementNumber == AnnouncemetData.AnnouncementNumber).FirstOrDefault();
            try
            {
                if (announcement != null)
                {
                    Console.WriteLine("announcement with this Announcement Number already exists.");
                    return CacheData.Announcemts;
                }

                CacheData.Announcemts.Add(AnnouncemetData);

                return CacheData.Announcemts;

            }
            catch(Exception ex)
            {
                return CacheData.Announcemts;
            }
           
         

        }

        public ObservableCollection<Announcement> DeletingAnnouncement(Announcement AnnouncemetData)
        {

            var announcement = CacheData.Announcemts.Where(x => x.AnnouncementNumber == AnnouncemetData.AnnouncementNumber).FirstOrDefault();
            if (announcement != null)
            {
                CacheData.Announcemts.Remove(announcement);
                Console.WriteLine("Announcement Deleted Successfully");

            }
            return CacheData.Announcemts;

        }
        public ObservableCollection<Announcement> UpdatingAnnouncement(Announcement AnnouncemetData)
        {
            var announcement = CacheData.Announcemts.Where(x => x.AnnouncementNumber == AnnouncemetData.AnnouncementNumber).FirstOrDefault();
            if (announcement != null)
            {

                announcement.AnnouncementDate = AnnouncemetData.AnnouncementDate;
                announcement.Annoucementt = AnnouncemetData.Annoucementt;
                announcement.Title = AnnouncemetData.Title;
                announcement.ForWhom = AnnouncemetData.ForWhom;
                
            }

            return CacheData.Announcemts;
        }
        public ObservableCollection<Announcement> FethcingAnnouncement()
        {
            return CacheData.Announcemts;
        }
    }
}
