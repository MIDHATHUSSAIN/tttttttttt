﻿using Cache.Lists;
using Repo.Repos;
using System.Collections.ObjectModel;

namespace Server.HandleData.Logics
{
    public class CoursesLogic
    {
        public ObservableCollection<Courses> AddCourse(Courses CourseData)
        {
            var course = CacheData.Courses.Where(x => x.ClassName == CourseData.ClassName).FirstOrDefault();
            if (course != null)
            {
                Console.WriteLine("Course with this Class Name already exists.");
                return CacheData.Courses;
            }

            CacheData.Courses.Add(CourseData);

            return CacheData.Courses;

        }

        public ObservableCollection<Courses> DeletingCourse(Courses CourseData)
        {

            var course = CacheData.Courses.Where(x => x.ClassName == CourseData.ClassName).FirstOrDefault();
            if (course != null)
            {
                CacheData.Courses.Remove(CourseData);
               

            }
            return CacheData.Courses; ;

        }
        public ObservableCollection<Courses> UpdatingCourse(Courses CourseData)
        {
            var course = CacheData.Courses.Where(x => x.ClassName == CourseData.ClassName).FirstOrDefault();
            if (course != null)
            {

                course.SubjectName1 = CourseData.SubjectName1;
                course.SubjectName2 = CourseData.SubjectName2;
                course.SubjectName3 = CourseData.SubjectName3;
                course.SubjectName4 = CourseData.SubjectName4;
                course.SubjectName5 = CourseData.SubjectName5;
                course.SubjectName6 = CourseData.SubjectName6;
                course.SubjectName7 = CourseData.SubjectName7;
                course.Subject1BookName = CourseData.Subject1BookName;
                course.Subject2BookName = CourseData.Subject2BookName;
                course.Subject3BookName = CourseData.Subject3BookName;
                course.Subject4BookName = CourseData.Subject4BookName;
                course.Subject5BookName = CourseData.Subject5BookName;
                course.Subject6BookName = CourseData.Subject6BookName;
                course.Subject7BookName = CourseData.Subject7BookName;
                
              
            }

             return CacheData.Courses; ;
        }
        public ObservableCollection<Courses> FethcingCourses()
        {
            return CacheData.Courses;
        }
    }
}
