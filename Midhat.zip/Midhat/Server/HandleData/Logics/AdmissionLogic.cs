﻿using Cache.FilesPath;
using Cache.Lists;
using Repo.Repos;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Uitilies.SerilizationAndDeserilization;

namespace Server.HandleData.Logics
{
    public class AdmissionLogic
    {
        public ObservableCollection<Admission> AddAdmission(Admission AdmissionData)
        {
           

            if(CacheData.Admissions.Count < 1)
            {
                CacheData.Admissions.Add(AdmissionData);
            }
           

            return CacheData.Admissions;

        }

        public ObservableCollection<Admission> DeletingAdmission()
        {

           
                CacheData.Admissions.Clear(); // ✅ remove only one item
            Console.WriteLine("Deleted Successfully");
            SerilizingAndDeserilizing.SaveData(
       Constants.AdmissionFilePath,
       CacheData.Admissions,
       "Admissions"
   );



            return CacheData.Admissions; // ✅ don't recreate list
        }

        public ObservableCollection<Admission> FetchingAdmission()
        {
            return CacheData.Admissions;

        }
    }
}
