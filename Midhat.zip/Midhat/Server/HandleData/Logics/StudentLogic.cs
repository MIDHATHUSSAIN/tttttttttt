﻿using Cache.Lists;
using Repo.Repos;
using System.Collections.ObjectModel;

namespace Server.HandleData.Logics
{
    public class StudentLogic
    {
       
        public ObservableCollection<Student> AddStudent(Student StudentData)
        {
            var student = CacheData.Students.Where(x => x.StudentEmail == StudentData.StudentEmail).FirstOrDefault();
            if (student != null)
            {
                Console.WriteLine("Student with this email already exists.");
                return CacheData.Students;
            }

            CacheData.Students.Add(StudentData);

            return CacheData.Students;
        }

        public ObservableCollection<Student> DeletingStudent(Student StudentData)
        {

            var student = CacheData.Students.Where(x => x.StudentEmail == StudentData.StudentEmail).FirstOrDefault();
            if (student != null)
            {
                CacheData.Students.Remove(student);
                Console.WriteLine("Student Deleted Successfully");

            }
            return CacheData.Students;

        }
        public ObservableCollection<Student> UpdatingStudent(Student StudentData)
        {
            var student = CacheData.Students.Where(x => x.StudentEmail == StudentData.StudentEmail).FirstOrDefault();
            if (student != null)
            {

                student.StudentName = StudentData.StudentName;
                student.StudentFatherName = StudentData.StudentFatherName;
                student.StudentPhone = StudentData.StudentPhone;
                student.StudentFee = StudentData.StudentFee;
                student.StudentClass = StudentData.StudentClass;
                student.JoiningDate = StudentData.JoiningDate;
              
            }

            return CacheData.Students;
        }
        public ObservableCollection<Student> FethcingStudent()
        {
            return CacheData.Students;
        }
    }
}
